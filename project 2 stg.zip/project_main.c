/*
NAME: SOBHA SIMHADRI
DATE:18/09/2024
DISCRIPTION:(steganographic system that can hide and retrieve secrete information within such as an image or audio)
*/
#include<stdio.h>
#include<string.h>						//Including necessary hearder files for the project
#include"encode.h"
#include"decode.h"

int main(int argc,char *argv[])					//Storing the command line arguements in int argc and char argv[]
{
    EncodeInfo encInfo;						//Declarations of structures i.e (Encoding and Decoding)
    DecodeInfo decInfo;
    if(argc > 1)						//Input arguements should be greater than one
    {
        if(strcmp(argv[1],"-e") == 0)				//Verifying the user operations for Encoding
	{
    	   if(argc >= 4)
    	   {
    	    encInfo.src_image_fname = argv[2];
    	    encInfo.secret_fname = argv[3];
    	    if(argc == 4)	    				//if argc ==4 holds true which represents user is not given target file.
    	    	encInfo.stego_image_fname = "steged_img.bmp";	//Assigning the default output file name for encoding if not present.
	    else
		encInfo.stego_image_fname = argv[4];		//Assiging the user output name if present.

	        if(do_encoding(&encInfo) == e_success)		//Calling do_encoding process to perform encode operations
	            printf("## Encoding Done Successfully ##\n");
	        else
		    return 0;
	   }
    	   else
    	   {
		printf("Unsupported files or invalid entries\n");
		return 0;
    	   }
	}
        else if(strcmp(argv[1], "-d") == 0)			//Verifiying the user input for Decoding
	{
	  if(argc >=3)
	  {
    	    decInfo.src_image_fname = argv[2];
	    if(argc == 3)				//If argc ==3 in decoding holds true which represents user is not given output/target file 
    	    	decInfo.secret_fname = "decoded";	//Assigning decoded.<decoded_extn_name> as default in case of absence of output file
	    else
    	    	decInfo.secret_fname = argv[3];		//Assigning the user output file name if given. 

	    if(do_decoding(&decInfo) == e_success)	//Calling the do_decoding function to perform decoding operations
		printf("## Decoding Done Successfully ##\n");
	    else
		return 0;
	  }
    	  else
    	  {
		printf("invalid or error\n");	//Error printing to console if conditions holds false
		return 0;
    	  }
        }
    }
    else
    {
	printf("./a.out:Encoding:./a.out -e <.bmp file > <.txt file>\n");
	printf("./a.out:Decoding:./a.out -d<.bmp file>\n");
	return 0;
    }
    return 0;
}

